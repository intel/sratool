CREATE DATABASE  IF NOT EXISTS `sra_prod` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `sra_prod`;
-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sra_prod
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sra_riskfactor`
--

DROP TABLE IF EXISTS `sra_riskfactor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `sra_riskfactor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `riskfactor` varchar(450) NOT NULL,
  `guidance` varchar(3000) DEFAULT NULL,
  `magicnumber` float DEFAULT NULL,
  `id_riskassessment_type` float DEFAULT NULL,
  `prob_asset_weight` float DEFAULT '0',
  `impact_ asset_weight` float DEFAULT '0',
  `prob_mechanism_weight` float DEFAULT '0',
  `impact_mechanism_weight` float DEFAULT '0',
  `neutral_score` float DEFAULT '0',
  `is_asset` float DEFAULT '0',
  `is_mechanism` float DEFAULT '0',
  `sucesivo` float DEFAULT NULL,
  `version` varchar(10) DEFAULT NULL,
  `recommendations` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=188 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sra_riskfactor`
--

LOCK TABLES `sra_riskfactor` WRITE;
/*!40000 ALTER TABLE `sra_riskfactor` DISABLE KEYS */;
INSERT INTO `sra_riskfactor` VALUES (170,'What would be the skilled required to maximize the likelihood of a successful attack','Threat Agent Factors-> Skill level: How technically skilled is this group of threat agents?',NULL,5,5,5,1.2,-1,1,1,0,1,'v1','THREAT AGENT -  Use the worst-case '),(172,'Vulnerability, Hole or weakness in the application: likelihood of this being discovered and exploited','Vulnerability-> Easy of Discovery : likelihood of the particular vulnerability involved being discovered and exploited',NULL,5,5,5,-1,-1,1,1,0,5,'v1','Assume the threat agentS selected on the first questions'),(173,'How motivated would be a group to find and exploit a vulnerability','Threat Agent Factors-> Motive:  How motivated is this group of threat agents to find and exploit this vulnerability?',NULL,5,5,5,-1,-1,1,1,0,2,'v1','Use the worst-case threat agen'),(174,'What resources and opportunities are required to find and exploit this vulnerability?','Threat Agent Factors-> Opportunity:  What resources and opportunities are required for this group of threat agents to find and exploit this vulnerability?',NULL,5,5,5,-1,-1,1,1,0,3,'v1','Use the worst-case threat agen'),(175,'How large is this group of  Threat agents? ','Threat Agent Factors->Population Size:  How large is this group of threat agents? ',NULL,5,5,5,-1,-1,1,1,0,4,'v1','Use the worst-case threat agen'),(176,'How easy is  to actually exploit this vulnerability','Vulnerability-> Easy of exploit: How easy is it for this group of threat agents to actually exploit this vulnerability',NULL,5,5,5,-1,-1,1,1,0,6,'v1','Assume the threat agentS selected on the first questions'),(177,'How well known is this vulnerability','Vulnerability-> Awareness: How well known is this vulnerability to this group of threat agents?',NULL,5,5,5,-1,-1,1,1,0,7,'v1','Assume the threat agentS selected on the first questions'),(179,'How likely is an exploit to be detected?','Vulnerability-> Intrusion Detection: How likely is an exploit to be detected?',NULL,5,5,5,-1,-1,1,1,0,8,'v1','Assume the threat agentS selected on the first questions'),(180,'How much data could be disclosed and how sensitive is it?','Technical Impact Factors-> Loss of confidentiality',NULL,5,-1,-1,1,1,1,0,1,9,'v1','The goal is to estimate the magnitude of the impact on the system if the vulnerability were to be exploited.'),(181,'How much data could be corrupted and how damaged is it?','Technical Impact Factors-> Loss of Integrity',NULL,5,-1,-1,1,1,1,0,1,10,'v1','The goal is to estimate the magnitude of the impact on the system if the vulnerability were to be exploited.'),(182,'How much service could be lost and how vital is it? ','Technical Impact Factors-> Loss of Availability',NULL,5,-1,-1,1,1,1,0,1,11,'v1','The goal is to estimate the magnitude of the impact on the system if the vulnerability were to be exploited.'),(183,'Are the threat agents\' actions traceable to an individual? ','Technical Impact Factors-> Loss of Accountability',NULL,5,-1,-1,1,1,1,0,1,12,'v1','The goal is to estimate the magnitude of the impact on the system if the vulnerability were to be exploited.'),(184,'How much financial damage will result from an exploit? ','Business Impact Factors-> Financial Damage',NULL,5,-1,-1,1,1,1,0,1,13,'v1',NULL),(185,'Would an exploit result in reputation damage that would harm the business? ','Business Impact Factors-> Reputation  Damage',NULL,5,-1,-1,1,1,1,0,1,14,'v1',NULL),(186,'How much exposure does non-compliance introduce?','Business Impact Factors-> Non-Compliancel Damage',NULL,5,-1,-1,1,1,1,0,1,15,'v1',NULL),(187,'How much personally identifiable information could be disclosed? ','Business Impact Factors-> Privacy Violation',NULL,5,-1,-1,1,1,1,0,1,16,'v1',NULL);
/*!40000 ALTER TABLE `sra_riskfactor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-25 15:06:13
