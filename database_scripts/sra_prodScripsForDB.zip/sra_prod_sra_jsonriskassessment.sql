CREATE DATABASE  IF NOT EXISTS `sra_prod` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `sra_prod`;
-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sra_prod
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sra_jsonriskassessment`
--

DROP TABLE IF EXISTS `sra_jsonriskassessment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `sra_jsonriskassessment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_info` int(11) NOT NULL,
  `sra_jsonriskassessment` json DEFAULT NULL,
  `id_of_type` int(11) DEFAULT NULL,
  `comments` varchar(45) DEFAULT NULL,
  `sdl_jsonrequest` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sra_jsonriskassessment_id_of_type` (`id_of_type`),
  KEY `idx_sra_jsonriskassessment_type_info` (`type_info`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COMMENT='This will collect the information to post to the prediction API';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sra_jsonriskassessment`
--

LOCK TABLES `sra_jsonriskassessment` WRITE;
/*!40000 ALTER TABLE `sra_jsonriskassessment` DISABLE KEYS */;
INSERT INTO `sra_jsonriskassessment` VALUES (1,1,'{\"id\": 0, \"reqid\": 0, \"sdl_url\": \"3401\", \"sratype\": 5, \"ssg_psec\": -1, \"sra_owner\": \"00000002\", \"attributes\": [], \"pr_version\": \"0\", \"threatminer\": false, \"project_name\": \"Pre-Loaded Project=>2400\", \"sraownerName\": \"Mundo Mendez, Ricardo2\", \"owner_details\": \"Name: Mundo Mendez, Ricardo1                           Email: ricardo@mundo.com         IDSID: ricardo1\", \"project_owner\": \"00000001\", \"sraownerEmail\": \"ricardo@mundo.com\", \"sraownerIDSID\": \"ricardo2\", \"projectownerName\": \"Mundo Mendez, Ricardo1\", \"sraowner_details\": \"Name: Mundo Mendez, Ricardo2                           Email: ricardo@mundo.com         IDSID: ricardo2\", \"projectownerEmail\": \"ricardo@mundo.com\", \"projectownerIDSID\": \"ricardo1\"}',804,'new_project',NULL),(2,2,'{\"projectid\": 804, \"reasoning\": {\"0\": \"asdasd\", \"1\": \"fghdfh\", \"2\": \"gfhdfgh\", \"3\": \"gfhdfgh\", \"4\": \"gfhdfghd\", \"5\": \"gfhdfh\", \"6\": \"fghdfghd\", \"7\": \"gfhdfgh\", \"8\": \"gfhdfghd\", \"9\": \"fghdfghdfg\", \"10\": \"gfhdfghd\", \"11\": \"gfhdfghd\", \"12\": \"fghdfhd\", \"13\": \"gfhdfghd\", \"14\": \"gfhdfgh\", \"15\": \"fghdfghd\"}, \"requestid\": 0, \"idValueGuide\": {\"0\": \"5\", \"1\": \"1\", \"2\": \"4\", \"3\": \"3\", \"4\": \"3\", \"5\": \"4\", \"6\": \"3\", \"7\": \"4\", \"8\": \"4\", \"9\": \"5\", \"10\": \"4\", \"11\": \"4\", \"12\": \"5\", \"13\": \"4\", \"14\": \"4\", \"15\": \"4\"}}',804,'requestDetail',NULL);
/*!40000 ALTER TABLE `sra_jsonriskassessment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-25 15:06:12
