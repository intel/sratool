CREATE DATABASE  IF NOT EXISTS `sra_prod` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `sra_prod`;
-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sra_prod
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sra_users`
--

DROP TABLE IF EXISTS `sra_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `sra_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `enabled` tinyint(4) DEFAULT '1',
  `role_access` int(11) DEFAULT NULL,
  `login_count` int(11) DEFAULT '0',
  `cookie_string` varchar(64) DEFAULT NULL,
  `wwid` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wwid` (`wwid`)
) ENGINE=InnoDB AUTO_INCREMENT=451 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sra_users`
--

LOCK TABLES `sra_users` WRITE;
/*!40000 ALTER TABLE `sra_users` DISABLE KEYS */;
INSERT INTO `sra_users` VALUES (221,'ricardo2','Mundo Mendez, Ricardo2','ricardo@mundo.com',1,15,0,'','00000002'),(235,'ricardo1','Mundo Mendez, Ricardo1','ricardo@mundo.com',1,15,0,'','00000001'),(236,'ricardo3','Mundo Mendez, Ricardo3','ricardo@mundo.com',1,10,0,'','00000003'),(238,'ricardo4','Mundo Mendez, Ricardo4','ricardo@mundo.com',1,10,0,'','00000004'),(446,'ricardo5','Mundo Mendez, Ricardo5','ricardo@mundo.com',1,10,0,'','00000005'),(448,'ricardo6','Mundo Mendez, Ricardo6','ricardo@mundo.com',1,10,0,'','00000006'),(449,'ricardo7','Mundo Mendez, Ricardo7','ricardo@mundo.com',1,10,0,'','00000007'),(450,'ricardo8','Mundo Mendez, Ricardo8','ricardo@mundo.com',1,10,0,'','00000008');
/*!40000 ALTER TABLE `sra_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-25 15:06:12
