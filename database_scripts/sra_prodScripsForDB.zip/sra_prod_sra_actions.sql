CREATE DATABASE  IF NOT EXISTS `sra_prod` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `sra_prod`;
-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sra_prod
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sra_actions`
--

DROP TABLE IF EXISTS `sra_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `sra_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sdlaction` varchar(45) DEFAULT NULL,
  `action` varchar(2500) DEFAULT NULL,
  `actionlink` varchar(2500) DEFAULT NULL,
  `statuslow` varchar(45) DEFAULT NULL,
  `statusmedium` varchar(45) DEFAULT NULL,
  `statushigh` varchar(45) DEFAULT NULL,
  `statuscritical` varchar(45) DEFAULT NULL,
  `comments` varchar(45000) DEFAULT NULL,
  `commentslink` varchar(2500) DEFAULT NULL,
  `sdlversion` varchar(45) DEFAULT NULL,
  `id_riskassessment_type` int(2) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sra_actions`
--

LOCK TABLES `sra_actions` WRITE;
/*!40000 ALTER TABLE `sra_actions` DISABLE KEYS */;
INSERT INTO `sra_actions` VALUES (42,'SDL000','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(43,'SDL050','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance','http://itdoclib.intel.com/getdoc.asp?id=144457','1.0',1),(44,'SDL100','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(45,'SDL110','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(46,'SDL120','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','0','0','0','SDL Guidance',NULL,'1.0',1),(47,'SDL130','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(48,'SDL150','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(49,'SDL160','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','0','0','1','1','SDL Guidance',NULL,'1.0',1),(50,'SDL170','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(51,'SDL180','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','0','0','1','1','SDL Guidance',NULL,'1.0',1),(52,'SDL190','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(53,'SDL200','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','0','0','1','1','SDL Guidance',NULL,'1.0',1),(54,'SDL230','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','n/a','n/a','n/a','n/a','SDL Guidance',NULL,'1.0',1),(55,'SDL260','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(56,'SDL290','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','0','1','1','1','SDL Guidance',NULL,'1.0',1),(57,'SDL300','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(58,'SDL305','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(59,'SDL310','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','n/a','n/a','n/a','n/a','SDL Guidance',NULL,'1.0',1),(60,'SDL320','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(61,'SDL325','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(62,'SDL330','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance','https://sp2010.amr.ith.intel.com/sites/sdl/Pages/Lists/Activities.aspx#ActivityID=14','1.0',1),(63,'SDL335','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(64,'SDL340','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance','https://sp2010.amr.ith.intel.com/sites/sdl/Pages/Lists/Activities.aspx#ActivityID=46','1.0',1),(65,'SDL345','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','0','1','1','1','SDL Guidance',NULL,'1.0',1),(66,'SDL350','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','0','0','1','1','SDL Guidance',NULL,'1.0',1),(67,'SDL355','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(68,'SDL375','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','n/a','n/a','n/a','n/a','SDL Guidance',NULL,'1.0',1),(69,'SDL385','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(70,'SDL395','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','0','1','1','1','SDL Guidance',NULL,'1.0',1),(71,'SDL400','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','n/a','n/a','n/a','n/a','SDL Guidance',NULL,'1.0',1),(72,'SDL410','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','0','1','1','1','SDL Guidance',NULL,'1.0',1),(73,'SDL430','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(74,'SDL440','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(75,'SDL450','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(76,'SDL460','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','n/a','n/a','n/a','n/a','SDL Guidance','https://wiki.ith.intel.com/display/SWPedia/Virus+Scanning+Software+Distributions#VirusScanningSoftwareDistributions-Whatarethevirusscanningrequirementsforopen-source%3F','1.0',1),(77,'SDL470','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(78,'SDL480','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance','https://sp2010.amr.ith.intel.com/sites/sdl/SDL%20Templates/Survivability_Plan_Template.docx','1.0',1),(79,'SDL490','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','1','1','1','1','SDL Guidance',NULL,'1.0',1),(80,'N/A','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','0','0','1','1','SDL Guidance',NULL,'1.0',1),(81,'N/A','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','0','0','0','1','SDL Guidance',NULL,'1.0',1),(82,'N/A','SDL Action','https://www.microsoft.com/en-us/securityengineering/sdl/faq','0','0','0','1','SDL Guidance',NULL,'1.0',1);
/*!40000 ALTER TABLE `sra_actions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-25 15:06:12
